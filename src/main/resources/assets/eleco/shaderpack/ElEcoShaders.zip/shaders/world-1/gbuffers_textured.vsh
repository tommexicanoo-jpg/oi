#version 120
#define NETHER
#include "/lib/prog/textured_vs.glsl"
