#version 120
uniform vec3 fogColor;
void main() {
    vec3 c = min(fogColor * 1.5 + vec3(0.04, 0.012, 0.0), vec3(1.0));
    gl_FragData[0] = vec4(c, 1.0);
}
