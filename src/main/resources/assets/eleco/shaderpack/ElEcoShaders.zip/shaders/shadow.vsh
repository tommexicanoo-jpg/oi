#version 120

#include "/lib/common.glsl"

varying vec2 texcoord;
varying vec4 glcolor;

void main() {
    texcoord = gl_MultiTexCoord0.xy;
    glcolor = gl_Color;
#ifdef SHADOWS
    gl_Position = ftransform();
    gl_Position.xyz = distortShadow(gl_Position.xyz);
#else
    // sin sombras: la geometria se descarta fuera de pantalla
    gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
#endif
}
