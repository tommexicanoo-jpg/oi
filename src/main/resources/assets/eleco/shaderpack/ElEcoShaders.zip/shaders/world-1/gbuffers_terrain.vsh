#version 120
#define NETHER
#include "/lib/prog/terrain_vs.glsl"
