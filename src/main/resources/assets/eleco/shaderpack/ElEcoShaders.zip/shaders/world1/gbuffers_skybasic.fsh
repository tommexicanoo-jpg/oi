#version 120
uniform vec3 fogColor;
void main() {
    vec3 c = min(fogColor * 3.0 + vec3(0.05, 0.02, 0.09), vec3(1.0));
    gl_FragData[0] = vec4(c, 1.0);
}
